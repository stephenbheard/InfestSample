﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Box_InputFile = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Box_OutputFile = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Box_NumRand = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Box_InfestationThreshold1 = New System.Windows.Forms.TextBox()
        Me.Box_InfestationThreshold2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Box_InfestationThreshold4 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Box_InfestationThreshold3 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Box_InfestationThreshold5 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Box_StartTransectA = New System.Windows.Forms.TextBox()
        Me.Box_StartTransectB = New System.Windows.Forms.TextBox()
        Me.Box_Jitter = New System.Windows.Forms.TextBox()
        Me.Box_EndTransectA = New System.Windows.Forms.TextBox()
        Me.Box_EndTransectB = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Box_MapFile = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Box_InputFile
        '
        Me.Box_InputFile.Location = New System.Drawing.Point(140, 59)
        Me.Box_InputFile.Name = "Box_InputFile"
        Me.Box_InputFile.Size = New System.Drawing.Size(181, 20)
        Me.Box_InputFile.TabIndex = 0
        Me.Box_InputFile.Text = "\data\Dataset S1.csv"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(110, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Input data file:"
        '
        'Box_OutputFile
        '
        Me.Box_OutputFile.Location = New System.Drawing.Point(140, 97)
        Me.Box_OutputFile.Name = "Box_OutputFile"
        Me.Box_OutputFile.Size = New System.Drawing.Size(181, 20)
        Me.Box_OutputFile.TabIndex = 2
        Me.Box_OutputFile.Text = "\data\output data.csv"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(122, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Output data file:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(94, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(233, 31)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "InfestSample 1.10"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(62, 525)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(91, 33)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Run"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Box_NumRand
        '
        Me.Box_NumRand.Location = New System.Drawing.Point(232, 466)
        Me.Box_NumRand.Name = "Box_NumRand"
        Me.Box_NumRand.Size = New System.Drawing.Size(59, 20)
        Me.Box_NumRand.TabIndex = 6
        Me.Box_NumRand.Text = "10000"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 466)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(206, 20)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Number of Randomizations:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(12, 180)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(176, 20)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Infestation threshold 1 :"
        '
        'Box_InfestationThreshold1
        '
        Me.Box_InfestationThreshold1.Location = New System.Drawing.Point(215, 180)
        Me.Box_InfestationThreshold1.Name = "Box_InfestationThreshold1"
        Me.Box_InfestationThreshold1.Size = New System.Drawing.Size(32, 20)
        Me.Box_InfestationThreshold1.TabIndex = 9
        Me.Box_InfestationThreshold1.Text = "1"
        '
        'Box_InfestationThreshold2
        '
        Me.Box_InfestationThreshold2.Location = New System.Drawing.Point(215, 209)
        Me.Box_InfestationThreshold2.Name = "Box_InfestationThreshold2"
        Me.Box_InfestationThreshold2.Size = New System.Drawing.Size(32, 20)
        Me.Box_InfestationThreshold2.TabIndex = 11
        Me.Box_InfestationThreshold2.Text = "3"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(12, 209)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(172, 20)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Infestation threshold 2:"
        '
        'Box_InfestationThreshold4
        '
        Me.Box_InfestationThreshold4.Location = New System.Drawing.Point(215, 269)
        Me.Box_InfestationThreshold4.Name = "Box_InfestationThreshold4"
        Me.Box_InfestationThreshold4.Size = New System.Drawing.Size(32, 20)
        Me.Box_InfestationThreshold4.TabIndex = 15
        Me.Box_InfestationThreshold4.Text = "7"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(12, 269)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(172, 20)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Infestation threshold 4:"
        '
        'Box_InfestationThreshold3
        '
        Me.Box_InfestationThreshold3.Location = New System.Drawing.Point(215, 240)
        Me.Box_InfestationThreshold3.Name = "Box_InfestationThreshold3"
        Me.Box_InfestationThreshold3.Size = New System.Drawing.Size(32, 20)
        Me.Box_InfestationThreshold3.TabIndex = 13
        Me.Box_InfestationThreshold3.Text = "5"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(12, 240)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(172, 20)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Infestation threshold 3:"
        '
        'Box_InfestationThreshold5
        '
        Me.Box_InfestationThreshold5.Location = New System.Drawing.Point(215, 299)
        Me.Box_InfestationThreshold5.Name = "Box_InfestationThreshold5"
        Me.Box_InfestationThreshold5.Size = New System.Drawing.Size(32, 20)
        Me.Box_InfestationThreshold5.TabIndex = 17
        Me.Box_InfestationThreshold5.Text = "10"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(12, 299)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(172, 20)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Infestation threshold 5:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(12, 347)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(247, 20)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "End sampling units for transect A:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(12, 408)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(141, 20)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "Jitter for transects:"
        '
        'Box_StartTransectA
        '
        Me.Box_StartTransectA.Location = New System.Drawing.Point(266, 347)
        Me.Box_StartTransectA.Name = "Box_StartTransectA"
        Me.Box_StartTransectA.Size = New System.Drawing.Size(32, 20)
        Me.Box_StartTransectA.TabIndex = 21
        Me.Box_StartTransectA.Text = "1"
        '
        'Box_StartTransectB
        '
        Me.Box_StartTransectB.Location = New System.Drawing.Point(266, 378)
        Me.Box_StartTransectB.Name = "Box_StartTransectB"
        Me.Box_StartTransectB.Size = New System.Drawing.Size(32, 20)
        Me.Box_StartTransectB.TabIndex = 22
        '
        'Box_Jitter
        '
        Me.Box_Jitter.Location = New System.Drawing.Point(186, 408)
        Me.Box_Jitter.Name = "Box_Jitter"
        Me.Box_Jitter.Size = New System.Drawing.Size(32, 20)
        Me.Box_Jitter.TabIndex = 23
        Me.Box_Jitter.Text = "20"
        '
        'Box_EndTransectA
        '
        Me.Box_EndTransectA.Location = New System.Drawing.Point(327, 347)
        Me.Box_EndTransectA.Name = "Box_EndTransectA"
        Me.Box_EndTransectA.Size = New System.Drawing.Size(32, 20)
        Me.Box_EndTransectA.TabIndex = 24
        Me.Box_EndTransectA.Text = "200"
        '
        'Box_EndTransectB
        '
        Me.Box_EndTransectB.Location = New System.Drawing.Point(327, 378)
        Me.Box_EndTransectB.Name = "Box_EndTransectB"
        Me.Box_EndTransectB.Size = New System.Drawing.Size(32, 20)
        Me.Box_EndTransectB.TabIndex = 25
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(12, 378)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(247, 20)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "End sampling units for transect B:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(12, 130)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(121, 20)
        Me.Label13.TabIndex = 27
        Me.Label13.Text = "Output map file:"
        '
        'Box_MapFile
        '
        Me.Box_MapFile.Location = New System.Drawing.Point(140, 130)
        Me.Box_MapFile.Name = "Box_MapFile"
        Me.Box_MapFile.Size = New System.Drawing.Size(181, 20)
        Me.Box_MapFile.TabIndex = 26
        Me.Box_MapFile.Text = "\data\output map.csv"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(344, 59)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 28
        Me.Button2.Text = "Browse"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(344, 95)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 29
        Me.Button3.Text = "Browse"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(344, 128)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 30
        Me.Button4.Text = "Browse"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(396, 525)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(91, 33)
        Me.Button5.TabIndex = 31
        Me.Button5.Text = "Help"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(202, 583)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(140, 13)
        Me.Label14.TabIndex = 32
        Me.Label14.Text = "Free software: GNU GPL v3"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(438, 94)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(95, 23)
        Me.Button6.TabIndex = 33
        Me.Button6.Text = "Change path"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(438, 127)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(95, 23)
        Me.Button7.TabIndex = 34
        Me.Button7.Text = "Change path"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(556, 602)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Box_MapFile)
        Me.Controls.Add(Me.Box_EndTransectB)
        Me.Controls.Add(Me.Box_EndTransectA)
        Me.Controls.Add(Me.Box_Jitter)
        Me.Controls.Add(Me.Box_StartTransectB)
        Me.Controls.Add(Me.Box_StartTransectA)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Box_InfestationThreshold5)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Box_InfestationThreshold4)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Box_InfestationThreshold3)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Box_InfestationThreshold2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Box_InfestationThreshold1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Box_NumRand)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Box_OutputFile)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Box_InputFile)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Box_InputFile As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Box_OutputFile As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Box_NumRand As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Box_InfestationThreshold1 As System.Windows.Forms.TextBox
    Friend WithEvents Box_InfestationThreshold2 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Box_InfestationThreshold4 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Box_InfestationThreshold3 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Box_InfestationThreshold5 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Box_StartTransectA As System.Windows.Forms.TextBox
    Friend WithEvents Box_StartTransectB As System.Windows.Forms.TextBox
    Friend WithEvents Box_Jitter As System.Windows.Forms.TextBox
    Friend WithEvents Box_EndTransectA As System.Windows.Forms.TextBox
    Friend WithEvents Box_EndTransectB As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Box_MapFile As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button

End Class
